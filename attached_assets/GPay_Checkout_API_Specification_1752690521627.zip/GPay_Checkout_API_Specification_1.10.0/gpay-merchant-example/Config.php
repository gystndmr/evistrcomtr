<?php

const BASE_URL = "https://payment-sandbox.gpayprocessing.com";
const MERCHANT_ID = "xxxxxxxxxx";
const PUBLIC_KEY = "-----BEGIN PUBLIC KEY-----
MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxu+5iLOm7KCXoGxUMHX5
...
gB4Mx5Xv1P3kpwzYwlaFt9yxmSwaU1aac+wHjciVCwSplzr3m4YOx78dnL8WotCG
PR1ofGsEO8/N/qJuggQc2P8CAwEAAQ==
-----END PUBLIC KEY-----
";
const PRIVATE_KEY = "-----BEGIN PRIVATE KEY-----
MIIJQQIBADANBgkqhkiG9w0BAQEFAASCCSswggknAgEAAoICAQDwgPXMA8tv7boG
...
bWeAkMhf0DaBzSFZjtt1veFkyx8DiM7impsqyKCqjzmHQpq5xmI2Jzm/ON2oyrSi
8S7wZ3XcsaLzlzMXrxhykwsDFBFg
-----END PRIVATE KEY-----
";