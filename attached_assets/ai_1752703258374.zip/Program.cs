﻿using vize.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Localization;
using System.Globalization;
using System.Reflection;
using vize.Services;
using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);


#region Localizer
builder.Services.AddSingleton<LanguageService>();
builder.Services.AddLocalization(options => options.ResourcesPath = "Resources");
builder.Services.AddMvc().AddViewLocalization().AddDataAnnotationsLocalization(options =>
    options.DataAnnotationLocalizerProvider = (type, factory) =>
    {
        var assemblyName = new AssemblyName(typeof(SharedResource).GetTypeInfo().Assembly.FullName);
        return factory.Create(nameof(SharedResource), assemblyName.Name);
    });

builder.Services.Configure<RequestLocalizationOptions>(options =>
{
    var supportCultures = new List<CultureInfo>
    {
        new CultureInfo("en-US"),
        new CultureInfo("tr-TR"),
        new CultureInfo("ar"), //(Arabic - Arapça)
        new CultureInfo("de-DE"), //(German - Almanca)
        new CultureInfo("fr-FR"), //(Fransa - Français)
        new CultureInfo("es-ES"), //(Spanish - Ýspanyolca)
        new CultureInfo("zh-CN"), //(Chinese (Simplified) - Çince (Basitleþtirilmiþ))
    };
    options.DefaultRequestCulture = new RequestCulture(culture: "en-US", uiCulture: "en-US");
    options.SupportedCultures = supportCultures;
    options.SupportedUICultures = supportCultures;
    options.RequestCultureProviders = new List<IRequestCultureProvider>
    {
        new CookieRequestCultureProvider(),                   // Tarayıcıya kaydedilen kültür bilgisi
        new AcceptLanguageHeaderRequestCultureProvider()      // <--- Burada tarayıcı/sistem dili devreye girer
    };
});
#endregion

builder.Services.AddControllersWithViews().AddRazorRuntimeCompilation();

builder.Services.AddScoped<dal>();
builder.Services.AddScoped<sql>();

builder.Configuration.AddJsonFile("appsettings.json");


var app = builder.Build();



app.MapGet("/odeme-basarili/{guid}", (string guid) =>
{
    // Gelen 'guid' ile bir iþlem yapýlabilir ya da baþka bir route'a yönlendirme yapýlabilir.
    return Results.Redirect($"/OdemeBasarili?guid={guid}");
});



app.MapGet("/Odeme/OdemeBasarisiz/{guid}", (string guid) => guid);


// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}

app.UseStaticFiles();

var supportCultures = new List<CultureInfo>
    {
        new CultureInfo("en-US"),
        new CultureInfo("tr-TR"),
        new CultureInfo("ar"), //(Arabic - Arapça)
        new CultureInfo("de-DE"), //(German - Almanca)
        new CultureInfo("fr-FR"), //(Fransa - Français)
        new CultureInfo("es-ES"), //(Spanish - Ýspanyolca)
        new CultureInfo("zh-CN"), //(Chinese (Simplified) - Çince (Basitleþtirilmiþ))
    };
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture("en-US"),
    SupportedCultures = supportCultures,
    SupportedUICultures = supportCultures,
    RequestCultureProviders = new IRequestCultureProvider[]
    {
        new CookieRequestCultureProvider(),                   // Kullanıcının seçtiği dil (çerez)
        new AcceptLanguageHeaderRequestCultureProvider()      // Sistem/tarayıcı dili
    }
});

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    //pattern: "{controller=Home}/{action=BilgilendiriciYazi}/{id?}");
    pattern: "{controller=Home}/{action=AnasayfaBasvuruTanitim}/{id?}");

app.Run();
