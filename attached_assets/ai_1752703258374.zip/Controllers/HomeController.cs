using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using vize.Models;
using vize.Services;
namespace vize.Controllers
{
    public class HomeController : BaseController
    {
        private readonly LanguageService _localization;
        private readonly sql _sql;

        // Constructor'da parametrelerin doðru þekilde atanmasý
        public HomeController(sql sql, LanguageService localization) : base(sql)
        {
            _sql = sql;
            _localization = localization;
        }

        public IActionResult ChangeLanguage(string culture)
        {
            if (string.IsNullOrEmpty(culture))
            {
                culture = "en-US";
            }

            Response.Cookies.Append(CookieRequestCultureProvider.DefaultCookieName,
                CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture)), new CookieOptions()
                {
                    Expires = DateTimeOffset.UtcNow.AddYears(1)
                });

            var referer = Request.Headers["Referer"].ToString();
            if (string.IsNullOrEmpty(referer))
            {
                return RedirectToAction("Anasayfa", "Home");
            }

            return Redirect(referer);
        }
        public IActionResult Anasayfa(IFormCollection form)
        {

            string mesaj = "";
            string secilen = "";
            string ulke_id = "";
            string milliyet_teyit = "";
            string seyehat_belgesi_id = "";
            string turkiye_varis_tarihi = "";
            string cinsiyet = "";
            string ad = "";
            string soyad = "";
            string dogum_tarihi = "";
            string dogum_yeri = "";
            string anne_adi = "";
            string baba_adi = "";

            string kimlik_karti_numarasi = "";
            string kimlik_karti_verilis_tarihi = "";
            string kimlik_karti_son_kullanma_tarihi = "";

            string pasaport_no = "";
            string pasaport_verilis_tarihi = "";
            string pasaport_son_kullanma_tarihi = "";
            string destekleyici_belge = "-1";
            string tel = "";
            string eposta = "";
            string eposta_onay = "";
            string adres = "";

            string currentCulture = Thread.CurrentThread.CurrentCulture.Name.ToString().Replace("-", "_");

            if (form.Count > 0)
            {
                #region tanimlamalar

                if (!string.IsNullOrWhiteSpace(form["input_260"])) secilen = Convert.ToString(form["input_260"]);
                secilen = (secilen == "2") ? "2" : "1";

                if (!string.IsNullOrWhiteSpace(form["input_7"])) ulke_id = Convert.ToString(form["input_7"]);
                else mesaj = _localization.Getkey("mesaj16").Value;

                if (!string.IsNullOrWhiteSpace(form["input_194"])) adres = Convert.ToString(form["input_194"]);
                else mesaj = _localization.Getkey("mesaj14").Value;

                if (!string.IsNullOrWhiteSpace(form["input_188"])) eposta = Convert.ToString(form["input_188"]);
                else mesaj = _localization.Getkey("mesaj12").Value;

                eposta_onay = form["input_188_2"].ToString();

                if (!string.IsNullOrWhiteSpace(form["input_278"])) tel = Convert.ToString(form["input_278"]);
                else mesaj = _localization.Getkey("mesaj15").Value;

                if (ulke_id == "1" || ulke_id == "3" || ulke_id == "16" || ulke_id == "23" || ulke_id == "32" || ulke_id == "35" || ulke_id == "59" || ulke_id == "87" || ulke_id == "90" || ulke_id == "110" || ulke_id == "138" || ulke_id == "148" || ulke_id == "150" || ulke_id == "155" || ulke_id == "170" || ulke_id == "177" || ulke_id == "182" || ulke_id == "209" || ulke_id == "212" || ulke_id == "213")
                {
                    if (form["input_574"].ToString() != "") destekleyici_belge = Convert.ToString(form["input_574"]);
                    else mesaj = _localization.Getkey("mesaj18").Value;
                }

                if (secilen == "1")
                {
                    if (!string.IsNullOrWhiteSpace(form["input_65"])) pasaport_son_kullanma_tarihi = Convert.ToString(form["input_65"]);
                    else mesaj = _localization.Getkey("mesaj20").Value;

                    if (!string.IsNullOrWhiteSpace(form["input_64"])) pasaport_verilis_tarihi = Convert.ToString(form["input_64"]);
                    else mesaj = _localization.Getkey("mesaj22").Value;

                    if (!string.IsNullOrWhiteSpace(form["input_63"])) pasaport_no = Convert.ToString(form["input_63"]);
                    else mesaj = _localization.Getkey("mesaj24").Value;
                }
                else if (secilen == "2")
                {
                    if (!string.IsNullOrWhiteSpace(form["input_91"])) kimlik_karti_son_kullanma_tarihi = Convert.ToString(form["input_91"]);
                    else mesaj = _localization.Getkey("mesaj26").Value;

                    if (!string.IsNullOrWhiteSpace(form["input_90"])) kimlik_karti_verilis_tarihi = Convert.ToString(form["input_90"]);
                    else mesaj = _localization.Getkey("mesaj27").Value;

                    if (!string.IsNullOrWhiteSpace(form["input_89"])) kimlik_karti_numarasi = Convert.ToString(form["input_89"]);
                    else mesaj = _localization.Getkey("mesaj25").Value;
                }

                if (!string.IsNullOrWhiteSpace(form["input_62"])) baba_adi = Convert.ToString(form["input_62"]);
                else mesaj = _localization.Getkey("mesaj21").Value;

                if (!string.IsNullOrWhiteSpace(form["input_61"])) anne_adi = Convert.ToString(form["input_61"]);
                else mesaj = _localization.Getkey("mesaj19").Value;

                if (!string.IsNullOrWhiteSpace(form["input_60"])) dogum_yeri = Convert.ToString(form["input_60"]);
                else mesaj = _localization.Getkey("mesaj17").Value;

                if (!string.IsNullOrWhiteSpace(form["input_59"])) dogum_tarihi = Convert.ToString(form["input_59"]);
                else mesaj = _localization.Getkey("mesaj13").Value;

                if (!string.IsNullOrWhiteSpace(form["input_58"])) soyad = Convert.ToString(form["input_58"]);
                else mesaj = _localization.Getkey("mesaj28").Value;

                if (!string.IsNullOrWhiteSpace(form["input_57"])) ad = Convert.ToString(form["input_57"]);
                else mesaj = _localization.Getkey("mesaj30").Value;

                if (form["input_535"] != "") cinsiyet = Convert.ToString(form["input_535"]);
                else mesaj = _localization.Getkey("mesaj32").Value;

                if (!string.IsNullOrWhiteSpace(form["input_565"])) turkiye_varis_tarihi = Convert.ToString(form["input_565"]);
                else mesaj = _localization.Getkey("mesaj34").Value;

                if (!string.IsNullOrWhiteSpace(form["input_260"])) seyehat_belgesi_id = Convert.ToString(form["input_260"]);
                else mesaj = _localization.Getkey("mesaj36").Value;

                if (form.ContainsKey("input_577.1") && form["input_577.1"].ToString() == "on")
                    milliyet_teyit = Convert.ToString(form["input_577.1"]);
                else
                    mesaj = _localization.Getkey("mesaj38").Value;


                #endregion
                if (string.IsNullOrWhiteSpace(mesaj))
                {
                    if (eposta == eposta_onay)
                    {
                        if (EmailControl(eposta))
                        {
                            DataSet result = _sql.SP_INS_BASVURU(Convert.ToInt32(ulke_id), Convert.ToInt32(seyehat_belgesi_id), ConvertDateFormat(turkiye_varis_tarihi), Convert.ToInt32(cinsiyet), ad, soyad, ConvertDateFormat(dogum_tarihi),
                                     dogum_yeri, anne_adi, baba_adi,
                                     kimlik_karti_numarasi, ConvertDateFormat(kimlik_karti_verilis_tarihi), ConvertDateFormat(kimlik_karti_son_kullanma_tarihi),
                                     pasaport_no, ConvertDateFormat(pasaport_verilis_tarihi), ConvertDateFormat(pasaport_son_kullanma_tarihi),
                                      int.Parse(destekleyici_belge, NumberStyles.Integer, CultureInfo.InvariantCulture), tel, eposta, adres);

                            if (result.Tables.Count > 0)
                            {
                                if (result.Tables[0].Rows.Count > 0)
                                {
                                    string guid = result.Tables[0].Rows[0]["guid"].ToString();
                                    mesaj = "Başvurunuz başarılı.";
                                    TempData["guid"] = guid;

                                    CookieOptions options = new CookieOptions
                                    {
                                        Expires = DateTime.Now.AddDays(1),
                                        HttpOnly = true,
                                        Secure = true
                                    };
                                    Response.Cookies.Append("guid", guid, options);

                                    if (destekleyici_belge == "-1" || destekleyici_belge == "2")
                                    {
                                        //sigortaya gidecek.
                                        return RedirectToAction("SigortaOnBilgilendirme");
                                    }
                                    else
                                    {
                                        return RedirectToAction("Vize");
                                    }
                                }
                                else mesaj = _localization.Getkey("hata").Value;
                            }
                            else mesaj = _localization.Getkey("hata").Value;
                        }
                        else mesaj = _localization.Getkey("mesaj40").Value;
                    }
                    else mesaj = _localization.Getkey("mesaj41").Value;
                }
            }


            DataSet SP_SLC_ULKE = _sql.SP_SLC_ULKE(currentCulture);
            DataSet SP_SLC_SEYAHAT_BELGESI = _sql.SP_SLC_SEYAHAT_BELGESI(currentCulture);

            string telefon_kontrol = _localization.Getkey("telefon.kontrol").Value;

            ViewBag.telefon_kontrol = telefon_kontrol;
            ViewBag.currentCulture = currentCulture;
            ViewBag.ulke_id = ulke_id;
            ViewBag.milliyet_teyit = milliyet_teyit;
            ViewBag.seyehat_belgesi_id = seyehat_belgesi_id;
            ViewBag.turkiye_varis_tarihi = turkiye_varis_tarihi;
            ViewBag.cinsiyet = cinsiyet;
            ViewBag.ad = ad;
            ViewBag.soyad = soyad;
            ViewBag.dogum_tarihi = dogum_tarihi;
            ViewBag.dogum_yeri = dogum_yeri;
            ViewBag.anne_adi = anne_adi;
            ViewBag.baba_adi = baba_adi;
            ViewBag.kimlik_karti_numarasi = kimlik_karti_numarasi;
            ViewBag.kimlik_karti_verilis_tarihi = kimlik_karti_verilis_tarihi;
            ViewBag.kimlik_karti_son_kullanma_tarihi = kimlik_karti_son_kullanma_tarihi;
            ViewBag.pasaport_no = pasaport_no;
            ViewBag.pasaport_verilis_tarihi = pasaport_verilis_tarihi;
            ViewBag.pasaport_son_kullanma_tarihi = pasaport_son_kullanma_tarihi;
            ViewBag.destekleyici_belge = destekleyici_belge;
            ViewBag.tel = tel;
            ViewBag.eposta = eposta;
            ViewBag.eposta_onay = eposta_onay;
            ViewBag.adres = adres;

            ViewBag.mesaj = mesaj;
            ViewBag.SP_SLC_ULKE = SP_SLC_ULKE;
            ViewBag.SP_SLC_SEYAHAT_BELGESI = SP_SLC_SEYAHAT_BELGESI;


            return View();
        }
        public IActionResult AnasayfaBasvuruTanitim()
        {
            return View();
        }
        public IActionResult SigortaOnBilgilendirme()
        {
            DataSet SP_SLC_BASVURU = null;
            string guid = Request.Cookies["guid"].ToString();

            string currentCulture = Thread.CurrentThread.CurrentCulture.Name.ToString().Replace("-", "_");
            int ulke_id = 0;
            string ulke_ad = "";
            string seyahat_belgesi_ad = "";

            if (!string.IsNullOrWhiteSpace(guid))
            {
                SP_SLC_BASVURU = _sql.SP_SLC_BASVURU(guid);
                ulke_id = Convert.ToInt32(SP_SLC_BASVURU.Tables[0].Rows[0]["ulke_id"]);
                DataSet SP_SLC_ULKE_WID = _sql.SP_SLC_ULKE_WID(Convert.ToInt32(ulke_id), currentCulture);
                ulke_ad = SP_SLC_ULKE_WID.Tables[0].Rows[0][currentCulture].ToString();

                int seyahat_belgesi_id = Convert.ToInt32(SP_SLC_BASVURU.Tables[0].Rows[0]["seyahat_belgesi_id"]);
                DataSet SP_SLC_SEYAHAT_BELGESI_WID = _sql.SP_SLC_SEYAHAT_BELGESI_WID(seyahat_belgesi_id, currentCulture);
                seyahat_belgesi_ad = SP_SLC_SEYAHAT_BELGESI_WID.Tables[0].Rows[0][currentCulture].ToString();
            }
            else return RedirectToAction("Anasayfa");
            ViewBag.SP_SLC_BASVURU = SP_SLC_BASVURU;
            ViewBag.ulke_ad = ulke_ad;
            ViewBag.seyahat_belgesi_ad = seyahat_belgesi_ad;
            return View();
        }
        public IActionResult SigortaOdemeSecenek(IFormCollection form)
        {
            string guid = Request.Cookies["guid"].ToString();

            string mesaj = "";
            string ulke_id = "";
            string ulke_ad = "";
            string milliyet_teyit = "";
            string seyehat_belgesi_id = "";
            string cinsiyet = "";
            string ad = "";
            string soyad = "";
            string dogum_tarihi = "";
            string sigorta_baslangic_tarihi = "";
            string sigorta_fiyat = "";
            string pasaport_no = "";
            string kimlik_karti_numarasi = "";
            string tel = "";
            string eposta = "";
            string eposta_onay = "";
            string adres = "";
            DataSet SP_SLC_BASVURU = null;
            string currentCulture = Thread.CurrentThread.CurrentCulture.Name.ToString().Replace("-", "_");


            //Guncelleme icin daha onceki datalari getirdik. 
            if (!string.IsNullOrWhiteSpace(guid))
            {
                SP_SLC_BASVURU = _sql.SP_SLC_BASVURU(guid);
            }

            if (form.Count > 0)
            {
                #region tanimlamalar

                if (!string.IsNullOrWhiteSpace(form["input_7"])) ulke_id = Convert.ToString(form["input_7"]);
                else mesaj = _localization.Getkey("mesaj16").Value;

                if (!string.IsNullOrWhiteSpace(form["input_194"])) adres = Convert.ToString(form["input_194"]);
                else mesaj = _localization.Getkey("mesaj14").Value;

                if (!string.IsNullOrWhiteSpace(form["input_188"])) eposta = Convert.ToString(form["input_188"]);
                else mesaj = _localization.Getkey("mesaj12").Value;

                eposta_onay = form["input_188_2"].ToString();

                if (!string.IsNullOrWhiteSpace(form["input_278"])) tel = Convert.ToString(form["input_278"]);
                else mesaj = _localization.Getkey("mesaj15").Value;

                string TEST = FormatTarih(form["input_54"]);

                if (!string.IsNullOrWhiteSpace(form["input_54"])) sigorta_baslangic_tarihi = Convert.ToString(form["input_54"]);
                else mesaj = _localization.Getkey("mesaj45").Value;

                if (!string.IsNullOrWhiteSpace(form["input_409"])) sigorta_fiyat = Convert.ToString(form["input_409"]);
                else mesaj = _localization.Getkey("mesaj43").Value;

                if (!string.IsNullOrWhiteSpace(form["input_260"])) seyehat_belgesi_id = Convert.ToString(form["input_260"]);
                else mesaj = _localization.Getkey("mesaj33").Value;

                if (seyehat_belgesi_id == "1")
                {
                    if (!string.IsNullOrWhiteSpace(form["input_543"])) pasaport_no = Convert.ToString(form["input_543"]);
                    else mesaj = _localization.Getkey("mesaj23").Value;
                }
                if (seyehat_belgesi_id == "2")
                {
                    if (!string.IsNullOrWhiteSpace(form["input_89"])) kimlik_karti_numarasi = Convert.ToString(form["input_89"]);
                    else mesaj = _localization.Getkey("mesaj57").Value;
                }

                if (!string.IsNullOrWhiteSpace(form["input_59"])) dogum_tarihi = Convert.ToString(form["input_59"]);
                else mesaj = _localization.Getkey("mesaj13").Value;

                if (!string.IsNullOrWhiteSpace(form["input_58"])) soyad = Convert.ToString(form["input_58"]);
                else mesaj = _localization.Getkey("mesaj28").Value;

                if (!string.IsNullOrWhiteSpace(form["input_57"])) ad = Convert.ToString(form["input_57"]);
                else mesaj = _localization.Getkey("mesaj30").Value;

                if (form["input_429"] != "") cinsiyet = Convert.ToString(form["input_429"]);
                else mesaj = _localization.Getkey("mesaj32").Value;



                if (form.ContainsKey("input_592.1") && form["input_592.1"].ToString() == "on")
                    milliyet_teyit = Convert.ToString(form["input_592.1"]);
                else
                    mesaj = _localization.Getkey("mesaj38").Value;

                #endregion

                if (string.IsNullOrWhiteSpace(mesaj))
                {
                    if (eposta == eposta_onay)
                    {
                        if (EmailControl(eposta))
                        {
                            bool result = _sql.SP_UPT_BASVURU(guid, Convert.ToInt32(ulke_id), Convert.ToInt32(seyehat_belgesi_id),
                                Convert.ToInt32(cinsiyet), ad, soyad, ConvertDateFormat(dogum_tarihi), ConvertDateFormat(sigorta_baslangic_tarihi), Convert.ToInt32(sigorta_fiyat), pasaport_no, kimlik_karti_numarasi, tel, eposta, adres);
                            if (result)
                            {
                                bool donen = DetayMailGonder(guid);
                                return RedirectToAction("SigortaSonOnizleme", "Home");
                            }
                            else mesaj = _localization.Getkey("hata").Value;
                        }
                        else mesaj = _localization.Getkey("mesaj40").Value;
                    }
                    else mesaj = _localization.Getkey("mesaj41").Value;
                }
            }

            DataSet SP_SLC_SIGORTA_FIYATLARI = _sql.SP_SLC_SIGORTA_FIYATLARI();
            DataSet SP_SLC_ULKE = _sql.SP_SLC_ULKE(currentCulture);
            DataSet SP_SLC_SEYAHAT_BELGESI = _sql.SP_SLC_SEYAHAT_BELGESI(currentCulture);

            ulke_id = SP_SLC_BASVURU.Tables[0].Rows[0]["ulke_id"].ToString();
            DataSet SP_SLC_ULKE_WID = _sql.SP_SLC_ULKE_WID(Convert.ToInt32(ulke_id), currentCulture);
            ulke_ad = SP_SLC_ULKE_WID.Tables[0].Rows[0][currentCulture].ToString();
            ViewBag.ulke_ad = ulke_ad;


            ViewBag.mesaj = mesaj;
            ViewBag.currentCulture = currentCulture;
            ViewBag.SP_SLC_SIGORTA_FIYATLARI = SP_SLC_SIGORTA_FIYATLARI;
            ViewBag.SP_SLC_ULKE = SP_SLC_ULKE;
            ViewBag.SP_SLC_SEYAHAT_BELGESI = SP_SLC_SEYAHAT_BELGESI;
            ViewBag.SP_SLC_BASVURU = SP_SLC_BASVURU;
            return View();
        }
        public IActionResult SigortaSonOnizleme()
        {
            string guid = Request.Cookies["guid"].ToString();

            string currentCulture = Thread.CurrentThread.CurrentCulture.Name.ToString().Replace("-", "_");
            int gun = 0;
            decimal fiyat = 0;
            string ulke_ad = "";
            string seyahat_belgesi_ad = "";

            DataSet SP_SLC_BASVURU = null;
            if (!string.IsNullOrWhiteSpace(guid))
            {
                SP_SLC_BASVURU = _sql.SP_SLC_BASVURU(guid);

                //dile gore ulke adi cekiliyor.
                int ulke_id = Convert.ToInt32(SP_SLC_BASVURU.Tables[0].Rows[0]["ulke_id"]);
                DataSet SP_SLC_ULKE_WID = _sql.SP_SLC_ULKE_WID(Convert.ToInt32(ulke_id), currentCulture);
                ulke_ad = SP_SLC_ULKE_WID.Tables[0].Rows[0][currentCulture].ToString();

                //dile gore seyahat_belgesi_adi cekiliyor.
                int seyahat_belgesi_id = Convert.ToInt32(SP_SLC_BASVURU.Tables[0].Rows[0]["seyahat_belgesi_id"]);
                DataSet SP_SLC_SEYAHAT_BELGESI_WID = _sql.SP_SLC_SEYAHAT_BELGESI_WID(seyahat_belgesi_id, currentCulture);
                seyahat_belgesi_ad = SP_SLC_SEYAHAT_BELGESI_WID.Tables[0].Rows[0][currentCulture].ToString();


                int sigorta_fiyat_id = Convert.ToInt32(SP_SLC_BASVURU.Tables[0].Rows[0]["sigorta_fiyat_id"]);
                DataSet SP_SLC_SIGORTA_FIYAT_WID = _sql.SP_SLC_SIGORTA_FIYAT_WID(sigorta_fiyat_id);
                if (SP_SLC_SIGORTA_FIYAT_WID.Tables.Count > 0)
                {
                    if (SP_SLC_SIGORTA_FIYAT_WID.Tables[0].Rows.Count > 0)
                    {
                        gun = Convert.ToInt32(SP_SLC_SIGORTA_FIYAT_WID.Tables[0].Rows[0]["gun"]);
                        fiyat = Convert.ToDecimal(SP_SLC_SIGORTA_FIYAT_WID.Tables[0].Rows[0]["fiyat"]);
                    }
                }

            }
            ViewBag.gun = gun;
            ViewBag.fiyat = fiyat;
            ViewBag.ulke_ad = ulke_ad;
            ViewBag.seyahat_belgesi_ad = seyahat_belgesi_ad;
            ViewBag.SP_SLC_BASVURU = SP_SLC_BASVURU;
            return View();

        }
        public IActionResult Vize(IFormCollection form)
        {
            #region degiskenler
            DataSet SP_SLC_BASVURU = null;
            string guid = Request.Cookies["guid"].ToString();


            string mesaj = "";
            string ulke_id = "";
            string ulke_ad = "";
            string seyahat_belgesi_id = "";
            string vize_fiyat_id = "-1";
            string vize_fiyat_detay_id = "-1";
            string turkiye_varis_tarihi = "";
            string cinsiyet = "";
            string ad = "";
            string soyad = "";
            string dogum_tarihi = "";
            string dogum_yeri = "";
            string anne_adi = "";
            string baba_adi = "";
            string pasaport_numarasi = "";
            string pasaport_verilis_tarihi = "";
            string pasaport_son_kullanma_tarihi = "";

            string vize_destekleyici_belge = "-1";
            string vize_destekleyici_belge_detay_id = "-1";
            string vize_destekleyici_belge_no = "";
            string vize_destekleyici_belge_baslangic_tarihi = "";

            string ek_belge_son_kullanma_tarihi = "";
            string sinirsizCheck = "-1";

            string tel = "";
            string eposta = "";
            string eposta_onay = "";
            string adres = "";
            #endregion
            string currentCulture = Thread.CurrentThread.CurrentCulture.Name.ToString().Replace("-", "_");

            if (form.Count > 0)
            {
                #region tanimlamalar
                if (!string.IsNullOrWhiteSpace(form["input_7"])) ulke_id = Convert.ToString(form["input_7"]);
                else mesaj = _localization.Getkey("mesaj16").Value;

                if (!string.IsNullOrWhiteSpace(form["input_260"])) seyahat_belgesi_id = Convert.ToString(form["input_260"]);
                else mesaj = _localization.Getkey("mesaj87").Value;

                if (!string.IsNullOrWhiteSpace(form["input_46"])) vize_fiyat_id = Convert.ToString(form["input_46"]);
                else mesaj = _localization.Getkey("mesaj88").Value;

                if (vize_fiyat_id == "4")
                {
                    if (!string.IsNullOrWhiteSpace(form["input_286"])) vize_fiyat_detay_id = Convert.ToString(form["input_286"]);
                    else mesaj = _localization.Getkey("mesaj89").Value;
                }

                if (!string.IsNullOrWhiteSpace(form["input_54"]))
                {
                    DateTime dt;
                    string raw = Convert.ToString(form["input_54"]);
                    if (DateTime.TryParseExact(raw, new[] { "dd.MM.yyyy", "dd/MM/yyyy", "yyyy-MM-dd", "MM/dd/yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out dt))
                        turkiye_varis_tarihi = dt.ToString("dd.MM.yyyy");
                    else
                        turkiye_varis_tarihi = raw; // Format uygun değilse ham haliyle bırak
                }
                else
                {
                    mesaj = _localization.Getkey("mesaj83").Value;
                }

                if (form["input_535"] != "") cinsiyet = Convert.ToString(form["input_535"]);
                else mesaj = _localization.Getkey("mesaj75").Value;

                if (!string.IsNullOrWhiteSpace(form["input_62"])) baba_adi = Convert.ToString(form["input_62"]);
                else mesaj = _localization.Getkey("mesaj21").Value;

                if (!string.IsNullOrWhiteSpace(form["input_61"])) anne_adi = Convert.ToString(form["input_61"]);
                else mesaj = _localization.Getkey("mesaj19").Value;

                if (!string.IsNullOrWhiteSpace(form["input_60"])) dogum_yeri = Convert.ToString(form["input_60"]);
                else mesaj = _localization.Getkey("mesaj17").Value;

                if (!string.IsNullOrWhiteSpace(form["input_59"])) dogum_tarihi = Convert.ToString(form["input_59"]);
                else mesaj = _localization.Getkey("mesaj13").Value;

                if (!string.IsNullOrWhiteSpace(form["input_58"])) soyad = Convert.ToString(form["input_58"]);
                else mesaj = _localization.Getkey("mesaj28").Value;

                if (!string.IsNullOrWhiteSpace(form["input_57"])) ad = Convert.ToString(form["input_57"]);
                else mesaj = _localization.Getkey("mesaj30").Value;

                if (!string.IsNullOrWhiteSpace(form["input_65"])) pasaport_son_kullanma_tarihi = Convert.ToString(form["input_65"]);
                else mesaj = _localization.Getkey("mesaj20").Value;

                if (!string.IsNullOrWhiteSpace(form["input_64"])) pasaport_verilis_tarihi = Convert.ToString(form["input_64"]);
                else mesaj = _localization.Getkey("mesaj22").Value;

                if (!string.IsNullOrWhiteSpace(form["input_63"])) pasaport_numarasi = Convert.ToString(form["input_63"]);
                else mesaj = _localization.Getkey("mesaj24").Value;

                if (ulke_id == "1" || ulke_id == "3" || ulke_id == "16" || ulke_id == "23" || ulke_id == "32" || ulke_id == "35" || ulke_id == "59" || ulke_id == "87" || ulke_id == "90" || ulke_id == "110" || ulke_id == "138" || ulke_id == "148" || ulke_id == "150" || ulke_id == "155" || ulke_id == "170" || ulke_id == "177" || ulke_id == "182" || ulke_id == "209" || ulke_id == "212" || ulke_id == "213")
                {
                    if (form["input_66"].ToString() != "") vize_destekleyici_belge = Convert.ToString(form["input_66"]);
                    else mesaj = _localization.Getkey("mesaj67").Value;
                }

                if (form["input_67"].ToString() != "") vize_destekleyici_belge_detay_id = Convert.ToString(form["input_67"]);
                else mesaj = _localization.Getkey("mesaj68").Value;

                vize_destekleyici_belge_detay_id = ExtractValidValue(vize_destekleyici_belge_detay_id);

                if (form["input_290"].ToString() != "") vize_destekleyici_belge_no = Convert.ToString(form["input_290"]);
                else mesaj = _localization.Getkey("mesaj69").Value;

                sinirsizCheck = form.ContainsKey("input_83_1")? sinirsizCheck = "1" : "-1";

                if (sinirsizCheck != "1")
                {
                    if (vize_destekleyici_belge_detay_id != "2")
                    {
                        if (!string.IsNullOrWhiteSpace(form["input_72"])) ek_belge_son_kullanma_tarihi = Convert.ToString(form["input_72"]);
                        else mesaj = _localization.Getkey("mesaj70").Value;
                    }
                    else
                    {
                        if (!string.IsNullOrWhiteSpace(form["input_584"])) ek_belge_son_kullanma_tarihi = Convert.ToString(form["input_584"]);
                        else mesaj = _localization.Getkey("mesaj70").Value;
                    }

                }

                if (!string.IsNullOrWhiteSpace(form["input_278"])) tel = Convert.ToString(form["input_278"]);
                else mesaj = _localization.Getkey("mesaj15").Value;

                if (!string.IsNullOrWhiteSpace(form["input_194"])) adres = Convert.ToString(form["input_194"]);
                else mesaj = _localization.Getkey("mesaj14").Value;

                if (!string.IsNullOrWhiteSpace(form["input_188"])) eposta = Convert.ToString(form["input_188"]);
                else mesaj = _localization.Getkey("mesaj12").Value;

                if (!string.IsNullOrWhiteSpace(form["input_188_2"])) eposta_onay = Convert.ToString(form["input_188_2"]);
                if (!string.IsNullOrWhiteSpace(form["input_581"]))
                    vize_destekleyici_belge_baslangic_tarihi = Convert.ToString(form["input_581"]);


                #endregion
                if (string.IsNullOrWhiteSpace(mesaj))
                {
                    if (eposta == eposta_onay)
                    {
                        if (EmailControl(eposta))
                        {
                            if (sinirsizCheck == "-1")
                                sinirsizCheck = "0";

                            bool result = _sql.SP_UPT_BASVURU_EVIZE(guid, Convert.ToInt32(ulke_id), Convert.ToInt32(seyahat_belgesi_id), Convert.ToInt32(vize_fiyat_id), int.Parse(vize_fiyat_detay_id, NumberStyles.Integer, CultureInfo.InvariantCulture),
                                ConvertDateFormat(turkiye_varis_tarihi), Convert.ToInt32(cinsiyet),
                                ad, soyad, ConvertDateFormat(dogum_tarihi), dogum_yeri, anne_adi, baba_adi, pasaport_numarasi,
                                ConvertDateFormat(pasaport_verilis_tarihi), ConvertDateFormat(pasaport_son_kullanma_tarihi),
                                Convert.ToInt32(vize_destekleyici_belge), Convert.ToInt32(vize_destekleyici_belge_detay_id), vize_destekleyici_belge_no, ConvertDateFormat(ek_belge_son_kullanma_tarihi), Convert.ToInt32(sinirsizCheck), tel, eposta, adres, ConvertDateFormat(vize_destekleyici_belge_baslangic_tarihi));
                            if (result)
                            {
                                bool donen = DetayMailGonder(guid);
                                mesaj = "Baþvurunuz baþarýlý.";
                                return RedirectToAction("VizeSonOnizleme", "Home");
                            }
                            else mesaj = "Hata!";
                        }
                        else mesaj = _localization.Getkey("mesaj40").Value;
                    }
                    else mesaj = _localization.Getkey("mesaj41").Value;
                }
            }



            if (!string.IsNullOrWhiteSpace(guid))
            {
                SP_SLC_BASVURU = _sql.SP_SLC_BASVURU(guid);
            }


            string telefon_kontrol = _localization.Getkey("telefon.kontrol").Value;
            DataSet SP_SLC_ULKE = _sql.SP_SLC_ULKE(currentCulture);
            DataSet SP_SLC_SEYAHAT_BELGESI = _sql.SP_SLC_SEYAHAT_BELGESI(currentCulture);
            DataSet SP_SLC_VIZE_FIYATLARI = _sql.SP_SLC_VIZE_FIYATLARI();
            DataSet SP_SLC_VIZE_FIYATLARI_DETAY = _sql.SP_SLC_VIZE_FIYATLARI_DETAY(4);
            DataSet SP_SLC_VIZE_DESTEKLEYICI_BELGE_DETAY_WTUR1 = _sql.SP_SLC_VIZE_DESTEKLEYICI_BELGE_DETAY_WTUR(1);
            DataSet SP_SLC_VIZE_DESTEKLEYICI_BELGE_DETAY_WTUR2 = _sql.SP_SLC_VIZE_DESTEKLEYICI_BELGE_DETAY_WTUR(2);
            DataSet SP_SLC_VIZE_DESTEKLEYICI_BELGE = _sql.SP_SLC_VIZE_DESTEKLEYICI_BELGE();


            ulke_id = SP_SLC_BASVURU.Tables[0].Rows[0]["ulke_id"].ToString();
            DataSet SP_SLC_ULKE_WID = _sql.SP_SLC_ULKE_WID(Convert.ToInt32(ulke_id), currentCulture);
            ulke_ad = SP_SLC_ULKE_WID.Tables[0].Rows[0][currentCulture].ToString();
            ViewBag.ulke_ad = ulke_ad;
            ViewBag.currentCulture = currentCulture;
            ViewBag.telefon_kontrol = telefon_kontrol;
            ViewBag.SP_SLC_BASVURU = SP_SLC_BASVURU;
            ViewBag.SP_SLC_ULKE = SP_SLC_ULKE;
            ViewBag.SP_SLC_SEYAHAT_BELGESI = SP_SLC_SEYAHAT_BELGESI;
            ViewBag.SP_SLC_VIZE_FIYATLARI = SP_SLC_VIZE_FIYATLARI;
            ViewBag.SP_SLC_VIZE_FIYATLARI_DETAY = SP_SLC_VIZE_FIYATLARI_DETAY;
            ViewBag.SP_SLC_VIZE_DESTEKLEYICI_BELGE_DETAY_WTUR1 = SP_SLC_VIZE_DESTEKLEYICI_BELGE_DETAY_WTUR1;
            ViewBag.SP_SLC_VIZE_DESTEKLEYICI_BELGE_DETAY_WTUR2 = SP_SLC_VIZE_DESTEKLEYICI_BELGE_DETAY_WTUR2;
            ViewBag.SP_SLC_VIZE_DESTEKLEYICI_BELGE = SP_SLC_VIZE_DESTEKLEYICI_BELGE;


            return View();
        }
        public IActionResult VizeSonOnizleme()
        {
            //EGER VIZE FIYAT 4 SECÝLMEMÝSSE ONA GORE FÝYAT CIKAR EGER 4 SECÝLÝ ÝSE DETAYDAKÝ FÝYAT CÝKAR!!
            string vize_fiyat_id = "";
            string vize_fiyat_detay = "";
            string vize_fiyat_ad = "";
            string vize_fiyat_detay_id = "";

            int vize_destekleyici_belge = 0;
            int vize_destekleyici_belge_detay_id = 0;
            string vize_destekleyici_belge_ad = "";
            string ulke_ad = "";
            string seyahat_belgesi_ad = "";


            string guid = Request.Cookies["guid"].ToString();
            string currentCulture = Thread.CurrentThread.CurrentCulture.Name.ToString().Replace("-", "_");


            DataSet SP_SLC_BASVURU = null;
            if (!string.IsNullOrWhiteSpace(guid))
            {
                SP_SLC_BASVURU = _sql.SP_SLC_BASVURU(guid);
                vize_fiyat_id = SP_SLC_BASVURU.Tables[0].Rows[0]["vize_fiyat_id"].ToString();
                vize_fiyat_detay_id = SP_SLC_BASVURU.Tables[0].Rows[0]["vize_fiyat_detay_id"].ToString();

                DataSet SP_SLC_VIZE_FIYATLARI_WID = _sql.SP_SLC_VIZE_FIYATLARI_WID(Convert.ToInt32(vize_fiyat_id));
                vize_fiyat_ad = SP_SLC_VIZE_FIYATLARI_WID.Tables[0].Rows[0]["tur"].ToString();
                vize_fiyat_detay = SP_SLC_VIZE_FIYATLARI_WID.Tables[0].Rows[0]["fiyat"].ToString();
                if (vize_fiyat_id == "4")
                {
                    DataSet SP_SLC_VIZE_FIYATLARI_DETAY_WID = _sql.SP_SLC_VIZE_FIYATLARI_DETAY_WID(Convert.ToInt32(vize_fiyat_detay_id));
                    vize_fiyat_detay = SP_SLC_VIZE_FIYATLARI_DETAY_WID.Tables[0].Rows[0]["fiyat"].ToString();
                }

                vize_destekleyici_belge = Convert.ToInt32(SP_SLC_BASVURU.Tables[0].Rows[0]["vize_destekleyici_belge"]);
                vize_destekleyici_belge_detay_id = Convert.ToInt32(SP_SLC_BASVURU.Tables[0].Rows[0]["vize_destekleyici_belge_detay_id"]);
                DataSet SP_SLC_VIZE_DESTEKLEYICI_BELGE_DETAY_WTUR_WID = _sql.SP_SLC_VIZE_DESTEKLEYICI_BELGE_DETAY_WTUR_WID(vize_destekleyici_belge, vize_destekleyici_belge_detay_id);
                vize_destekleyici_belge_ad = SP_SLC_VIZE_DESTEKLEYICI_BELGE_DETAY_WTUR_WID.Tables[0].Rows[0]["ad"].ToString();

                //dile gore ulke
                int ulke_id = Convert.ToInt32(SP_SLC_BASVURU.Tables[0].Rows[0]["ulke_id"]);
                DataSet SP_SLC_ULKE_WID = _sql.SP_SLC_ULKE_WID(Convert.ToInt32(ulke_id), currentCulture);
                ulke_ad = SP_SLC_ULKE_WID.Tables[0].Rows[0][currentCulture].ToString();

                //dile gore seyahat belgesi
                int seyahat_belgesi_id = Convert.ToInt32(SP_SLC_BASVURU.Tables[0].Rows[0]["seyahat_belgesi_id"]);
                DataSet SP_SLC_SEYAHAT_BELGESI_WID = _sql.SP_SLC_SEYAHAT_BELGESI_WID(seyahat_belgesi_id, currentCulture);
                seyahat_belgesi_ad = SP_SLC_SEYAHAT_BELGESI_WID.Tables[0].Rows[0][currentCulture].ToString();
            }

            DataSet SP_SLC_EK_FIYATLAR = _sql.SP_SLC_EK_FIYATLAR();
            //DataSet SP_SLC_EK_FIYATLAR = new DataSet();
            ViewBag.SP_SLC_EK_FIYATLAR = SP_SLC_EK_FIYATLAR;
            //ViewBag.seyahat_belgesi_ad = seyahat_belgesi_ad;
            ViewBag.SP_SLC_BASVURU = SP_SLC_BASVURU;
            ViewBag.vize_fiyat_ad = vize_fiyat_ad;
            ViewBag.vize_fiyat_detay = vize_fiyat_detay;
            ViewBag.vize_destekleyici_belge_ad = vize_destekleyici_belge_ad;
            ViewBag.ulke_ad = ulke_ad;
            ViewBag.seyahat_belgesi_ad = seyahat_belgesi_ad;

            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult BilgilendiriciYazi()
        {
            ViewData["HideElements"] = true;
            return View();
        }
        public IActionResult Contact()
        {
            return View();
        }

    }
}
