﻿using Microsoft.AspNetCore.Mvc;

namespace vize.Controllers
{
    public class YardimController : Controller
    {
        public IActionResult kvkk_sozlesmesi()
        {
            return View();
        }

        public IActionResult mesafeli_satis_sozlesmesi()
        {
            return View();
        }

        public IActionResult iptal_iade_sozlesmesi()
        {
            return View();
        }

        public IActionResult iletisim_bilgileri()
        {
            return View();
        }

    }
}
