﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Globalization;
using System.Net.Mail;
using System.Net;
using System.Text.RegularExpressions;
using vize.Models;
using Newtonsoft.Json;

namespace vize.Controllers
{
    public class BaseController : Controller
    {
        public readonly sql _sql;

        public BaseController(sql sql)
        {
            _sql = sql;
        }
        public static bool EmailControl(string email)
        {
            if (string.IsNullOrEmpty(email))
                return false;

            // E-posta doğrulamak için regex deseni
            string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            Regex regex = new Regex(pattern);

            // Regex ile e-posta doğrulaması
            return regex.IsMatch(email);
        }
        public bool BosControl(DataSet ds)
        {
            bool donen = false;
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    donen = true;
                }
            }
            return donen;
        }
        public static string GetIPAddress(HttpContext context)
        {
            // Cloudflare IP
            string ipAddressX = context.Request.Headers["X-Forwarded-For"];
            // Cloudflare IP (alternative header)
            string ipAdressC = context.Request.Headers["CF-Connecting-IP"];
            // Direct connection IP
            string ipAdressR = context.Connection.RemoteIpAddress?.ToString();

            if (!string.IsNullOrEmpty(ipAdressC))
            {
                string[] addresses = ipAdressC.Split(',');
                if (addresses.Length > 0)
                {
                    return addresses[0].Trim();
                }
            }

            return ipAdressR;
        }
        public static string ConvertDateFormat(string inputDate)
        {
            DateTime tarih;
            if (DateTime.TryParse(inputDate, out tarih))
            {
                return tarih.ToString("yyyy-MM-dd");
            }
            if (DateTime.TryParseExact(inputDate, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out tarih))
            {
                string[] a = inputDate.Split('/');
                Array.Reverse(a);
                inputDate = string.Join('-', a);
                return inputDate;
            }
            //inputDate = inputDate.Replace(" ", "");
            //if (!string.IsNullOrWhiteSpace(inputDate))
            //{
            //    DateTime date;
            //    // Farklı tarih formatları
            //    string[] acceptedFormats = {
            //    "dd/MM/yyyy",  // Gün/Ay/Yıl formatı
            //    "MM/dd/yyyy",  // Ay/Gün/Yıl formatı
            //    "yyyy/MM/dd",  // Yıl/Ay/Gün formatı
            //    "yyyy-dd-MM",  // Yıl-Gün-Ay formatı
            //    "d/M/yyyy",    // Gün/Ay/Yıl (tek haneli gün/ay)
            //    "M/d/yyyy",    // Ay/Gün/Yıl (tek haneli gün/ay)
            //    "yyyy-MM-dd",
            //    "dd.MM.yyyy"
            //};

            //    // Tarih formatlarından birine uyan tarih string'ini çözümle
            //    if (DateTime.TryParseExact(inputDate, acceptedFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
            //    {
            //        // Tarih doğru şekilde dönüştürüldü, istediğimiz formata dönüştür
            //        return date.ToString("yyyy/MM/dd");
            //    }
            //}

            //// Eğer tarih geçersizse, boş bir string döndür
            return "";
        }
        public static string ExtractValidValue(string input)
        {
            string[] values = input.Split(',');

            foreach (string value in values)
            {
                if (value != "-1")
                {
                    return int.Parse(value).ToString();
                }
            }

            return "-1";
        }
        public static string FormatTarih(string tarih)
        {
            DateTime parsedDate;

            // Farklı tarih formatlarını kontrol ederek tarih string'ini DateTime'e dönüştür.
            string[] formatlar = { "dd/MM/yyyy", "MM/dd/yyyy", "yyyy-MM-dd", "yyyy/MM/dd", "dd-MM-yyyy", "M/d/yyyy h:mm:ss tt", "M/d/yyyy h:mm tt" };

            // Tarihi farklı formatlardan birine göre çözümle
            foreach (var format in formatlar)
            {
                if (DateTime.TryParseExact(tarih, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out parsedDate))
                {
                    // Tarih başarılı bir şekilde parse edildiyse, sadece tarihi al
                    return parsedDate.ToString("dd/MM/yyyy");
                }
            }

            // Eğer tarih formatı tanınmazsa, bir hata mesajı döndür
            return "Geçersiz tarih formatı";
        }
        public bool MailGonder(string GonderilecekMail, string baslik, string icerik)
        {
            bool donen = false;
            try
            {
                // Eğer birden fazla mail adresi varsa, virgülle ayırarak her birini ekliyoruz
                string[] words = GonderilecekMail.Split(',');
                MailMessage mesaj = new MailMessage();
                mesaj.From = new MailAddress("noreply1@teknolojikbilisim.com.tr"); // Gönderen adresi
                mesaj.Subject = baslik;
                mesaj.Body = icerik;
                mesaj.IsBodyHtml = true; // HTML formatında e-posta göndereceğiz

                // Her bir mail adresini ekliyoruz
                foreach (string email in words)
                {
                    mesaj.To.Add(email.Trim()); // `Trim` ile başındaki ve sonundaki boşlukları temizliyoruz
                }

                // SMTP client ayarları
                SmtpClient client = new SmtpClient("smtp.yandex.com", 587);
                client.Credentials = new NetworkCredential("noreply1@teknolojikbilisim.com.tr", "PassW0rd0");
                client.EnableSsl = true;

                // E-posta gönderme işlemi
                client.Send(mesaj);

                // Mail başarılı bir şekilde gönderildi, true döndür
                donen = true;
            }
            catch (Exception ex)
            {
                // Hata meydana geldiğinde, exception bilgilerini loglayabilirsiniz
                // Loglama yapılabilir (örneğin, hata mesajı veya stack trace yazılabilir)
                Console.WriteLine("Mail gönderme hatası: " + ex.Message);
                donen = false;
            }
            return donen; // Başarı durumuna göre true ya da false döndür
        }
        public bool DetayMailGonder(string guid)
        {
            bool donen = true;

            try
            {
                if (!string.IsNullOrEmpty(guid))
                {
                    string currentCulture = "tr_TR";

                    DataSet SP_SLC_BASVURU = _sql.SP_SLC_BASVURU(guid);
                    DataSet SP_SLC_MAIL_HESAPLARI = _sql.SP_SLC_MAIL_HESAPLARI();
                    for (int i = 0; i < SP_SLC_MAIL_HESAPLARI.Tables[0].Rows.Count; i++)
                    {
                        string GonderilecekMail = SP_SLC_MAIL_HESAPLARI.Tables[0].Rows[i]["mail_adresi"].ToString();
                        string Baslik = "Gelen Başvuru";

                        //ULKE
                        int ulke_id = Convert.ToInt32(SP_SLC_BASVURU.Tables[0].Rows[0]["ulke_id"]);
                        DataSet SP_SLC_ULKE_WID = _sql.SP_SLC_ULKE_WID(ulke_id, currentCulture);
                        string ulke_ad = SP_SLC_ULKE_WID.Tables[0].Rows[0][currentCulture].ToString();
                        //SEYAHAT BELGESİ
                        int seyahat_belgesi_id = Convert.ToInt32(SP_SLC_BASVURU.Tables[0].Rows[0]["seyahat_belgesi_id"]);
                        DataSet SP_SLC_SEYAHAT_BELGESI_WID = _sql.SP_SLC_SEYAHAT_BELGESI_WID(seyahat_belgesi_id, currentCulture);
                        string seyahat_belgesi_ad = SP_SLC_SEYAHAT_BELGESI_WID.Tables[0].Rows[0][currentCulture].ToString();

                        //DIGER VERILER
                        //BAK!!!
                        string turkiyeye_varis_tarihi = Convert.ToDateTime(SP_SLC_BASVURU.Tables[0].Rows[0]["turkiyeye_varis_tarihi"]).ToString("dd/MM/yyyy");

                        string cinsiyet = SP_SLC_BASVURU.Tables[0].Rows[0]["cinsiyet"].ToString();
                        if (cinsiyet == "1") cinsiyet = "Erkek";
                        else if (cinsiyet == "2") cinsiyet = "Kadın";

                        string ad = SP_SLC_BASVURU.Tables[0].Rows[0]["ad"].ToString();
                        string soyad = SP_SLC_BASVURU.Tables[0].Rows[0]["soyad"].ToString();

                        string dogum_tarihi = Convert.ToDateTime(SP_SLC_BASVURU.Tables[0].Rows[0]["dogum_tarihi"]).ToString("dd/MM/yyyy");

                        string dogum_yeri = SP_SLC_BASVURU.Tables[0].Rows[0]["dogum_yeri"].ToString();
                        string anne_adi = SP_SLC_BASVURU.Tables[0].Rows[0]["anne_adi"].ToString();
                        string baba_adi = SP_SLC_BASVURU.Tables[0].Rows[0]["baba_adi"].ToString();

                        string kimlik_karti_numarasi = SP_SLC_BASVURU.Tables[0].Rows[0]["kimlik_karti_numarasi"].ToString();
                        if (string.IsNullOrWhiteSpace(kimlik_karti_numarasi)) kimlik_karti_numarasi = "Kimlik kartı numarası girilmemiştir.";

                        string kimlik_karti_verilis_tarihi = Convert.ToDateTime(SP_SLC_BASVURU.Tables[0].Rows[0]["kimlik_karti_verilis_tarihi"]).ToString("yyyy");
                        if (kimlik_karti_verilis_tarihi == "1900") kimlik_karti_verilis_tarihi = "Kimlik kartı veriliş tarihi girilmemiştir.";
                        else kimlik_karti_verilis_tarihi = Convert.ToDateTime(SP_SLC_BASVURU.Tables[0].Rows[0]["kimlik_karti_verilis_tarihi"]).ToString("dd/MM/yyyy");


                        string kimlik_karti_son_kullanma_tarihi = Convert.ToDateTime(SP_SLC_BASVURU.Tables[0].Rows[0]["kimlik_karti_son_kullanma_tarihi"]).ToString("yyyy");
                        if (kimlik_karti_son_kullanma_tarihi == "1900") kimlik_karti_son_kullanma_tarihi = "Kimlik kartı son kullanma tarihi girilmemiştir.";
                        else kimlik_karti_son_kullanma_tarihi = Convert.ToDateTime(SP_SLC_BASVURU.Tables[0].Rows[0]["kimlik_karti_son_kullanma_tarihi"]).ToString("dd/MM/yyyy");

                        //Dolu gelirse ne olacak bak.
                        string sigorta_baslangic_tarihi = SP_SLC_BASVURU.Tables[0].Rows[0]["sigorta_baslangic_tarihi"].ToString();
                        if (string.IsNullOrWhiteSpace(sigorta_baslangic_tarihi)) sigorta_baslangic_tarihi = "Sigorta başlangıç tarihi girilmemiştir.";
                        else Convert.ToDateTime(SP_SLC_BASVURU.Tables[0].Rows[0]["sigorta_baslangic_tarihi"]).ToString("dd/MM/yyyy");

                        //SIGORTA FIYAT
                        string sigorta_fiyat_id = Convert.ToInt32(SP_SLC_BASVURU.Tables[0].Rows[0]["sigorta_fiyat_id"]).ToString(CultureInfo.InvariantCulture);
                        string secilen_sigorta_fiyat = "";
                        if (sigorta_fiyat_id != "-1")
                        {
                            DataSet SP_SLC_SIGORTA_FIYAT_WID = _sql.SP_SLC_SIGORTA_FIYAT_WID(Convert.ToInt32(sigorta_fiyat_id));
                            secilen_sigorta_fiyat = SP_SLC_SIGORTA_FIYAT_WID.Tables[0].Rows[0]["fiyat"].ToString();
                        }
                        else
                        {
                            secilen_sigorta_fiyat = "Sigorta fiyatı seçilmemiştir.";
                        }

                        //VIZE FIYAT
                        string vize_fiyat_id = Convert.ToInt32(SP_SLC_BASVURU.Tables[0].Rows[0]["vize_fiyat_id"]).ToString(CultureInfo.InvariantCulture);
                        string vize_fiyat_detay_id = Convert.ToInt32(SP_SLC_BASVURU.Tables[0].Rows[0]["vize_fiyat_detay_id"]).ToString(CultureInfo.InvariantCulture);
                        string secilen_vize_fiyat = "";
                        if (vize_fiyat_id != "-1")
                        {
                            DataSet SP_SLC_VIZE_FIYATLARI_WID = _sql.SP_SLC_VIZE_FIYATLARI_WID(Convert.ToInt32(vize_fiyat_id));
                            secilen_vize_fiyat = SP_SLC_VIZE_FIYATLARI_WID.Tables[0].Rows[0]["fiyat"].ToString();
                            if (vize_fiyat_id == "4" && vize_fiyat_detay_id != "-1")
                            {
                                DataSet SP_SLC_VIZE_FIYATLARI_DETAY_WID = _sql.SP_SLC_VIZE_FIYATLARI_DETAY_WID(Convert.ToInt32(vize_fiyat_detay_id));
                                secilen_vize_fiyat = SP_SLC_VIZE_FIYATLARI_DETAY_WID.Tables[0].Rows[0]["fiyat"].ToString();
                            }
                        }
                        else
                        {
                            secilen_vize_fiyat = "Vize fiyatı seçilmemiştir.";
                        }
                        string pasaport_numarasi = SP_SLC_BASVURU.Tables[0].Rows[0]["pasaport_numarasi"].ToString();


                        string pasaport_verilis_tarihi = Convert.ToDateTime(SP_SLC_BASVURU.Tables[0].Rows[0]["pasaport_verilis_tarihi"]).ToString("yyyy");
                        if (pasaport_verilis_tarihi == "1900") pasaport_verilis_tarihi = "Pasaport Veriliş Tarihi Girilmemiştir.";
                        else pasaport_verilis_tarihi = Convert.ToDateTime(SP_SLC_BASVURU.Tables[0].Rows[0]["pasaport_verilis_tarihi"]).ToString("dd/MM/yyyy");

                        string pasaport_son_kullanma_tarihi = Convert.ToDateTime(SP_SLC_BASVURU.Tables[0].Rows[0]["pasaport_son_kullanma_tarihi"]).ToString("yyyy");
                        if (pasaport_son_kullanma_tarihi == "1900") pasaport_son_kullanma_tarihi = "Pasaport Son Kullanma Tarihi Girilmemiştir.";
                        else pasaport_son_kullanma_tarihi = Convert.ToDateTime(SP_SLC_BASVURU.Tables[0].Rows[0]["pasaport_son_kullanma_tarihi"]).ToString("dd/MM/yyyy");


                        string destekleyici_belge = SP_SLC_BASVURU.Tables[0].Rows[0]["destekleyici_belge"].ToString();
                        if (destekleyici_belge == "1") destekleyici_belge = "Evet,var";
                        else destekleyici_belge = "Hayır,yok";


                        string vize_destekleyici_belge = Convert.ToInt32(SP_SLC_BASVURU.Tables[0].Rows[0]["vize_destekleyici_belge"]).ToString(CultureInfo.InvariantCulture);
                        string secilen_vize_destekleyici_belge = "";
                        if (vize_destekleyici_belge != "-1")
                        {
                            DataSet SP_VIZE_DESTEKLEYICI_BELGE_WID = _sql.SP_VIZE_DESTEKLEYICI_BELGE_WID(Convert.ToInt32(vize_destekleyici_belge));
                            secilen_vize_destekleyici_belge = SP_VIZE_DESTEKLEYICI_BELGE_WID.Tables[0].Rows[0]["ad"].ToString();
                        }
                        else secilen_vize_destekleyici_belge = "Vize destekleyici belge seçilmedi.";



                        string vize_destekleyici_belge_detay_id = Convert.ToInt32(SP_SLC_BASVURU.Tables[0].Rows[0]["vize_destekleyici_belge_detay_id"]).ToString(CultureInfo.InvariantCulture);
                        string secilen_vize_destekleyici_belge_detay = "";
                        if (vize_destekleyici_belge_detay_id != "-1")
                        {
                            DataSet SP_SLC_VIZE_DESTEKLEYICI_BELGE_DETAY_WTUR_WID = _sql.SP_SLC_VIZE_DESTEKLEYICI_BELGE_DETAY_WTUR_WID(Convert.ToInt32(vize_destekleyici_belge), Convert.ToInt32(vize_destekleyici_belge_detay_id));
                            secilen_vize_destekleyici_belge_detay = SP_SLC_VIZE_DESTEKLEYICI_BELGE_DETAY_WTUR_WID.Tables[0].Rows[0]["ad"].ToString();
                        }
                        else secilen_vize_destekleyici_belge_detay = "Vize destekleyici belge detay seçilmedi.";

                        string vize_destekleyici_belge_no = SP_SLC_BASVURU.Tables[0].Rows[0]["vize_destekleyici_belge_no"].ToString();
                        if (string.IsNullOrWhiteSpace(vize_destekleyici_belge_no)) vize_destekleyici_belge_no = "Vize destekleyici belge no girilmedi.";


                        string ek_belge_son_kullanma_tarihi = "";
                        string ek_belge_son_kullanma_tarihi_check = SP_SLC_BASVURU.Tables[0].Rows[0]["ek_belge_son_kullanma_tarihi_check"].ToString();
                        if (ek_belge_son_kullanma_tarihi_check == "1")
                        {
                            ek_belge_son_kullanma_tarihi = "Sınırsız";
                        }
                        else
                        {
                            if (!string.IsNullOrWhiteSpace(SP_SLC_BASVURU.Tables[0].Rows[0]["ek_belge_son_kullanma_tarihi"].ToString()))
                            {
                                ek_belge_son_kullanma_tarihi = Convert.ToDateTime(SP_SLC_BASVURU.Tables[0].Rows[0]["ek_belge_son_kullanma_tarihi"]).ToString("yyyy");
                                if (ek_belge_son_kullanma_tarihi == "1900") ek_belge_son_kullanma_tarihi = "Ek Belge Son Kullanma Tarihi Girilmemiştir.";
                                else ek_belge_son_kullanma_tarihi = Convert.ToDateTime(SP_SLC_BASVURU.Tables[0].Rows[0]["ek_belge_son_kullanma_tarihi"]).ToString("dd/MM/yyyy"); ;
                            }
                            else
                            {
                                ek_belge_son_kullanma_tarihi = "Ek belge son kullanma tarihi girilmemiştir.";
                            }
                        }
                        
                        string vize_destekleyici_belge_baslangic_tarihi = "Destekleyici Belge Baslangıç tarihi girilmemiştir";
                        if(!string.IsNullOrWhiteSpace(SP_SLC_BASVURU.Tables[0].Rows[0]["vize_destekleyici_belge_baslangic_tarihi"].ToString()))
                        vize_destekleyici_belge_baslangic_tarihi =Convert.ToDateTime(SP_SLC_BASVURU.Tables[0].Rows[0]["vize_destekleyici_belge_baslangic_tarihi"]).ToString("dd/MM/yyyy");

                        string tel = SP_SLC_BASVURU.Tables[0].Rows[0]["tel"].ToString();
                        string eposta = SP_SLC_BASVURU.Tables[0].Rows[0]["eposta"].ToString();
                        string adres = SP_SLC_BASVURU.Tables[0].Rows[0]["adres"].ToString();


                        string icerik = "Guid: " + guid + "<br>" +
                        "Seçilen Ülke: " + ulke_ad + "<br>" +
                        "Seçilen Seyahat Belgesi: " + seyahat_belgesi_ad + "<br>" +
                        "Türkiye'ye Varış Tarihi: " + turkiyeye_varis_tarihi + "<br>" +
                        "Cinsiyet: " + cinsiyet + "<br>" +
                        "Adı: " + ad + "<br>" +
                        "Soyad: " + soyad + "<br>" +
                        "Doğum Tarihi: " + dogum_tarihi + "<br>" +
                        "Doğum Yeri: " + dogum_yeri + "<br>" +
                        "Anne Adı: " + anne_adi + "<br>" +
                        "Baba Adı: " + baba_adi + "<br>" +
                        "Kimlik Kartı Numarası: " + kimlik_karti_numarasi + "<br>" +
                        "Kimlik Kartı Veriliş Tarihi: " + kimlik_karti_verilis_tarihi + "<br>" +
                        "Kimlik Kartı Son Kullanma Tarihi: " + kimlik_karti_son_kullanma_tarihi + "<br>" +
                        "Sigorta Başlangıç Tarihi: " + sigorta_baslangic_tarihi + "<br>" +
                        "Sigorta Secilen Fiyat: " + secilen_sigorta_fiyat + "<br>" +
                        "Vize Seçilen Fiyat: " + secilen_vize_fiyat + "<br>" +
                        "Pasaport Numarası: " + pasaport_numarasi + "<br>" +
                        "Pasaport Veriliş Tarihi: " + pasaport_verilis_tarihi + "<br>" +
                        "Pasaport Son Kullanma Tarihi: " + pasaport_son_kullanma_tarihi + "<br>" +
                        "Destekleyici Belge: " + destekleyici_belge + "<br>" +
                        "Destekleyici Belge Baslangıç Tarihi: " + vize_destekleyici_belge_baslangic_tarihi + "<br>" +

                        "Vize Destekleyici Belge: " + secilen_vize_destekleyici_belge + "<br>" +
                        "Vize Destekleyici Belge Detay: " + secilen_vize_destekleyici_belge_detay + "<br>" +
                        "Vize Destekleyici Belge No: " + vize_destekleyici_belge_no + "<br>" +
                        "Ek Belge Son Kullanma Tarihi: " + ek_belge_son_kullanma_tarihi + "<br>" +
                        "Ek Belge Son Kullanma Tarihi: " + ek_belge_son_kullanma_tarihi + "<br>" +
                        "Telefon: " + tel + "<br>" +
                        "E-Posta: " + eposta + "<br>" +
                        "Adres: " + adres;

                        donen = MailGonder(GonderilecekMail, Baslik, icerik);
                        return donen;
                    }
                }
            }
            catch (Exception ex)
            {
                donen = false;
                throw;
            }
            return donen;
        }
        public static string WebRequestIste(string adres)
        {
            string sonuc = "";
            try
            {
                HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(adres);
                httpWebRequest.Method = WebRequestMethods.Http.Get;
                httpWebRequest.Accept = "application/json";

                var response = (HttpWebResponse)httpWebRequest.GetResponse();

                using (var sr = new StreamReader(response.GetResponseStream()))
                {
                    sonuc = sr.ReadToEnd();
                }

                if (sonuc.ToLower().Contains("susd"))
                {
                    dynamic jObj = JsonConvert.DeserializeObject(sonuc);
                    foreach (var satir in jObj)
                    {
                        sonuc = satir.dblSatis;
                    }

                    if (string.IsNullOrEmpty(sonuc))
                    {
                        sonuc = "0";
                    }
                }
                else
                {
                    sonuc = "0";
                }

            }
            catch (Exception e)
            {
            }

            return sonuc;
        }
    }
}
